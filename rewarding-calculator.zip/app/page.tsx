import SpoonityRewardsCalculator from "./spoonity-rewards-calculator";

export default function Home() {
  return (
    <div>
      <SpoonityRewardsCalculator />
    </div>
  );
}
